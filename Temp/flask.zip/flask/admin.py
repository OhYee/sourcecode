import os

#!/usr/bin/python

def isAdmin(s):
    return 'id' in s and s['id'] == 'admin'

